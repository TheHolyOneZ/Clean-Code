def clean_code():
    filename = input("Enter the path to your Python file: ").strip()
    
    with open(filename, 'r') as file:
        lines = file.readlines()
    
    # Keep only non-empty lines and remove comments
    cleaned_lines = []
    for line in lines:
        # Remove inline comments while preserving code before the comment
        if '#' in line:
            line = line.split('#')[0]
        
        # Only keep line if it contains non-whitespace characters
        if line.strip():
            cleaned_lines.append(line.rstrip() + '\n')
    
    # Write back to file
    with open(filename, 'w') as file:
        file.writelines(cleaned_lines)
    
    print(f"File cleaned successfully: {filename}")
    print("Removed all empty lines and comments")

if __name__ == "__main__":
    clean_code()
